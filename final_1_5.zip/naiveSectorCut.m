%naive sector cutting
function O = naiveSectorCut(bound,im_hsv,hue_len)
    hue_img = im_hsv(:,:,1)*hue_len;
    [~,bW] = size(bound);
    
    if bW<2
        cut = midPoint(bound(1,1),bound(2,1),hue_len);
        sectorCenter = midPoint(bound(2,1),bound(1,1),hue_len);
        w = abs(sectorCenter-bound(1,1));
        
    else
        
    end
    
end
