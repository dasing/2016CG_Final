%shiftColor
function O = shiftColor(hue_img,c,w,low,high)
    
    tempmpL = zeros(size(hue_img));
    tempmapH = zeros(size(hue_img));
    allmap = zeros(size(hue_img));
    
    tempmapL(hue_img>low) = 1;
    tempmapH(hue_img<high) = 1;
    if low < high
        allmap = tempmapL.* tempmapH;
    else
        allmap = tempmapL + tempmapH;
    end
    centerMap = ones(size(hue_img))*c;
    
end
