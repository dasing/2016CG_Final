function hue_template_dist(im_hsv,temp_hue)

% type T

        
    
end