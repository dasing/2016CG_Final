function mid = midPoint(low,high,hue_len)
    
    if low<high
        half = round(((hue_len-high) + low)/2);
        if (high + half) >hue_len
            mid = low-half;
        else
            mid = high + half;
        end
    else
        mid = round((low+high)/2);
    end
end