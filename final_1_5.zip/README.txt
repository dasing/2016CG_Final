README

implemention of color harmonization

===========================
file:

ColorHarmon.m           //main file
hue_circle_hist.m       //draw histogram on a hue cirle 
hue_wheel.m             //draw a hue circle
hue_template_dis.m      //compute distance with hue tamplate
spaceBound.m            //input start radian and sector drgree, output corresponding lowerbound and upperbound on the wheel
spaceScore2.m           //calculate the score of input lowerbound and upperbound
calcTypeScore2.m        //calculate the best start degree and score of certain type

===========================



 